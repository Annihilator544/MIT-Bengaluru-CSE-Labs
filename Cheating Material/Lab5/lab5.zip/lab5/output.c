#include <stdio.h>
#include<string.h>
#include<ctype.h>

void first(){
	int h;
	READ("%d", &h);
	WRITE("hello there");
	WRITE("this is a print");
}

void main(){
	WRITE("In the main function")
}


/* Total scanf occurrences replaced: 1 */
/* Total printf occurrences replaced: 3 */
