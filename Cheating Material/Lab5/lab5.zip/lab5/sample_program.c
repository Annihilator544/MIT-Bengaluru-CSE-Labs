#include <stdio.h>
#include<string.h>
#include<ctype.h>

void first(){
	int h;
	scanf("%d", &h);
	printf("hello there");
	printf("this is a print");
}

void main(){
	printf("In the main function")
}
